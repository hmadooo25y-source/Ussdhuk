package com.example.ussdflow

object Csv {

    /** يقرأ CSV (RFC 4180 مبسّط). السطر الأول = أسماء المتغيرات. */
    fun parse(input: String): List<Map<String, String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var inQuotes = false
        val text = input.removePrefix("﻿")
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                inQuotes -> when {
                    ch == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                    ch == '"' -> inQuotes = false
                    else -> cell.append(ch)
                }
                ch == '"' -> inQuotes = true
                ch == ',' || ch == ';' -> { row.add(cell.toString().trim()); cell.clear() }
                ch == '\n' || ch == '\r' -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row.add(cell.toString().trim()); cell.clear()
                    if (row.any { it.isNotEmpty() }) rows.add(row)
                    row = mutableListOf()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) {
            row.add(cell.toString().trim())
            if (row.any { it.isNotEmpty() }) rows.add(row)
        }
        if (rows.size < 2) return emptyList()
        val header = rows[0]
        return rows.drop(1).map { r ->
            header.indices.associate { idx -> header[idx] to r.getOrElse(idx) { "" } }
        }
    }

    private fun esc(s: String): String {
        // حماية من حقن الصيغ عند فتح الملف في Excel
        val safe = if (s.isNotEmpty() && s[0] in "=+-@") "'$s" else s
        return if (safe.any { it == ',' || it == '"' || it == '\n' || it == '\r' || it == ';' })
            "\"" + safe.replace("\"", "\"\"") + "\"" else safe
    }

    fun write(headers: List<String>, rows: List<List<String>>): String =
        "﻿" + (listOf(headers) + rows).joinToString("\r\n") { r -> r.joinToString(",") { esc(it) } }
}
