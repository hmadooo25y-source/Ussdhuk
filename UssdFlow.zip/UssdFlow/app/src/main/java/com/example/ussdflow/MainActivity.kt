package com.example.ussdflow

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var statusView: TextView
    private lateinit var numberInput: EditText
    private lateinit var resultView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var runBtn: Button
    private lateinit var stopBtn: Button

    private val pickWorkflow = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { loadWorkflow(readText(it)) }
    }
    private val pickCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { loadCsv(readText(it)) }
    }
    private val saveResults = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let { writeText(it, RunController.resultsCsv()) }
    }
    private val saveLog = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let { writeText(it, RunController.logText()) }
    }
    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        // إشعارات Android 13+ اختيارية: بدونها يعمل التشغيل لكن الإشعار مخفي
        val required = granted.filterKeys { it != Manifest.permission.POST_NOTIFICATIONS }
        if (required.values.all { it }) RunService.start(applicationContext)
        else toast("الصلاحيات مطلوبة لتشغيل USSD")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "USSD Flow"
        buildUi()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    RunController.logLines.collect { lines ->
                        logView.text = lines.joinToString("\n")
                        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
                    }
                }
                launch {
                    RunController.lastName.collect { n ->
                        resultView.text = if (n.isBlank()) "" else "الاسم: $n"
                    }
                }
                launch {
                    RunController.running.collect { r ->
                        runBtn.isEnabled = !r
                        stopBtn.isEnabled = r
                        refreshStatus()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        statusView = TextView(this).apply { textSize = 14f }
        root.addView(statusView)

        numberInput = EditText(this).apply {
            hint = "أدخل الرقم (متغير number)"
            inputType = InputType.TYPE_CLASS_PHONE
            textDirection = View.TEXT_DIRECTION_LTR
            setSingleLine()
        }
        root.addView(numberInput)

        resultView = TextView(this).apply {
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextIsSelectable(true)
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(resultView)

        fun row(vararg buttons: Button) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.forEach { b ->
                l.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            root.addView(l)
        }
        fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
        }

        row(
            btn("فتح سيناريو JSON") { pickWorkflow.launch(arrayOf("*/*")) },
            btn("فتح CSV (اختياري)") { pickCsv.launch(arrayOf("*/*")) },
        )
        row(
            btn("تحميل المثال") { loadSample() },
            btn("تفعيل Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        )
        runBtn = btn("▶ تشغيل") { onRun() }
        stopBtn = btn("■ إيقاف") { RunController.stop() }.also { it.isEnabled = false }
        row(runBtn, stopBtn)
        row(
            btn("تصدير النتائج CSV") { saveResults.launch("ussd_results.csv") },
            btn("تصدير السجل") { saveLog.launch("ussd_log.txt") },
        )
        row(btn("مسح السجل") { RunController.clearLog() })

        logView = TextView(this).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
        }
        logScroll = ScrollView(this).apply { addView(logView) }
        root.addView(logScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun refreshStatus() {
        val wf = RunController.workflow
        val rows = RunController.rows
        val acc = if (UssdAccessibilityService.instance != null) "مفعّلة ✓" else "غير مفعّلة ✗"
        statusView.text = buildString {
            append("السيناريو: ").append(wf?.let { "${it.name} (${it.steps.size} خطوة، mode=${it.mode})" } ?: "—").append('\n')
            append("ملف CSV: ").append(rows?.let { "${it.size} صف" } ?: "بدون (تشغيل واحد)").append('\n')
            append("خدمة Accessibility: ").append(acc)
        }
    }

    private fun onRun() {
        val wf = RunController.workflow
        if (wf == null) { toast("افتح سيناريو أولًا"); return }
        val number = numberInput.text.toString().trim()
        val usesNumber = wf.steps.any { (it.text.orEmpty() + it.code.orEmpty()).contains("\${number}") }
        if (usesNumber && RunController.rows == null && number.isEmpty()) {
            toast("أدخل الرقم أولًا")
            return
        }
        RunController.extraVars = if (number.isEmpty()) emptyMap() else mapOf("number" to number)
        val needed = mutableListOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
        if (android.os.Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) RunService.start(applicationContext)
        else askPerms.launch(missing.toTypedArray())
    }

    private fun loadSample() {
        loadWorkflow(assets.open("sample_workflow.json").bufferedReader().use { it.readText() })
    }

    private fun loadWorkflow(json: String?) {
        if (json == null) return
        try {
            RunController.workflow = WorkflowParser.parse(json)
            RunController.log("✓ تم تحميل السيناريو: ${RunController.workflow?.name}")
        } catch (e: Exception) {
            toast("سيناريو غير صالح: ${e.message}")
            RunController.log("✗ سيناريو غير صالح: ${e.message}")
        }
        refreshStatus()
    }

    private fun loadCsv(text: String?) {
        if (text == null) return
        val rows = Csv.parse(text)
        RunController.rows = rows.ifEmpty { null }
        RunController.log(if (rows.isEmpty()) "⚠ ملف CSV فارغ أو بدون صفوف بيانات" else "✓ تم تحميل ${rows.size} صف من CSV")
        refreshStatus()
    }

    private fun readText(uri: Uri): String? = try {
        contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
    } catch (e: Exception) { toast("تعذّرت القراءة: ${e.message}"); null }

    private fun writeText(uri: Uri, text: String) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
            toast("تم الحفظ")
        } catch (e: Exception) { toast("تعذّر الحفظ: ${e.message}") }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
