package com.example.ussdflow

import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay
import kotlin.coroutines.coroutineContext

class WorkflowEngine(
    private val transport: UssdTransport,
    private val log: (String) -> Unit,
) {
    data class Result(
        val success: Boolean,
        val message: String,
        val lastResponse: String,
        val vars: Map<String, String>,
    )

    companion object {
        private const val MAX_STEPS = 500
        private const val FAIL = -1

        /** يحوّل الأرقام العربية/الفارسية إلى لاتينية ليعمل regex بشكل موحّد. */
        fun normalizeDigits(s: String): String = buildString {
            for (ch in s) append(
                when (ch) {
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    in '۰'..'۹' -> '0' + (ch - '۰')
                    else -> ch
                }
            )
        }
    }

    suspend fun run(wf: Workflow, initialVars: Map<String, String>): Result {
        val vars = LinkedHashMap<String, String>().apply {
            putAll(wf.variables)
            putAll(initialVars)
        }
        val index = wf.steps.withIndex().associate { it.value.id to it.index }
        var last = ""

        fun fail(msg: String): Result {
            log("✗ $msg")
            return Result(false, msg, last, vars)
        }

        fun render(t: String): String =
            Regex("\\$\\{(\\w+)}").replace(t) {
                val k = it.groupValues[1]
                if (k == "response") last else vars[k] ?: ""
            }

        fun resolve(id: String?, pos: Int): Int = when (id) {
            null -> pos + 1
            "end" -> wf.steps.size
            "fail" -> FAIL
            else -> index.getValue(id)
        }

        suspend fun <T> withRetries(retries: Int, block: suspend () -> T): T {
            var attempt = 0
            while (true) {
                try {
                    return block()
                } catch (e: UssdException) {
                    if (attempt >= retries) throw e
                    attempt++
                    log("↻ إعادة المحاولة $attempt/$retries بعد: ${e.message}")
                    delay(1500)
                }
            }
        }

        var pos = 0
        var guard = 0
        try {
            while (pos in wf.steps.indices) {
                if (++guard > MAX_STEPS) return fail("تجاوز $MAX_STEPS خطوة (حلقة محتملة)")
                coroutineContext.ensureActive()
                val s = wf.steps[pos]

                when (s.type) {
                    "dial" -> {
                        val code = render(s.code!!)
                        log("☎ [${s.id}] طلب $code")
                        last = normalizeDigits(withRetries(s.retries) { transport.dial(code, s.timeoutMs) })
                        log("← ${last.take(300)}")
                        pos = resolve(s.next, pos)
                    }
                    "reply" -> {
                        val text = render(s.text!!)
                        log("→ [${s.id}] رد: $text")
                        val r = withRetries(s.retries) { transport.reply(text, s.timeoutMs) }
                        if (s.timeoutMs > 0) {
                            last = normalizeDigits(r)
                            log("← ${last.take(300)}")
                        }
                        pos = resolve(s.next, pos)
                    }
                    "expect" -> {
                        val re = Regex(render(s.pattern!!), setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                        val m = re.find(last)
                        if (m != null) {
                            s.saveAs?.let { name ->
                                vars[name] = m.groupValues.getOrElse(1) { m.value }
                                m.groupValues.forEachIndexed { i, g -> vars["${name}_$i"] = g }
                                log("✓ [${s.id}] $name = ${vars[name]}")
                            }
                            pos = resolve(s.onMatch ?: s.next, pos)
                        } else {
                            if (s.onFail == null) return fail("[${s.id}] النمط '${s.pattern}' غير موجود في الرد")
                            log("… [${s.id}] لا تطابق، انتقال إلى ${s.onFail}")
                            pos = resolve(s.onFail, pos)
                        }
                    }
                    "if" -> {
                        val actual = vars[s.variable!!].orEmpty()
                        val cond = if (s.op != null) {
                            val a = actual.replace(',', '.').toDoubleOrNull()
                            val b = render(s.value.orEmpty()).replace(',', '.').toDoubleOrNull()
                            if (a == null || b == null) false else when (s.op) {
                                "lt" -> a < b
                                "gt" -> a > b
                                "le" -> a <= b
                                "ge" -> a >= b
                                "eq" -> a == b
                                else -> a != b
                            }
                        } else {
                            Regex(s.pattern!!, RegexOption.IGNORE_CASE).containsMatchIn(actual)
                        }
                        log("? [${s.id}] ${s.variable}='$actual' → $cond")
                        pos = resolve(if (cond) s.thenId else s.elseId, pos)
                    }
                    "set" -> {
                        vars[s.variable!!] = render(s.value.orEmpty())
                        pos = resolve(s.next, pos)
                    }
                    "delay" -> {
                        delay(s.ms)
                        pos = resolve(s.next, pos)
                    }
                    "log" -> {
                        log("ℹ ${render(s.text.orEmpty())}")
                        pos = resolve(s.next, pos)
                    }
                    "cancel" -> {
                        transport.close()
                        pos = resolve(s.next, pos)
                    }
                    "end" -> pos = wf.steps.size
                }
                if (pos == FAIL) return fail("انتقال صريح إلى fail من الخطوة [${s.id}]")
            }
        } catch (e: UssdException) {
            return fail(e.message ?: "خطأ USSD")
        } catch (e: SecurityException) {
            return fail("صلاحية ناقصة: ${e.message}")
        }
        log("✓ انتهى السيناريو")
        return Result(true, "تم", last, vars)
    }
}
