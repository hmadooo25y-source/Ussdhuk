package com.example.ussdflow

import org.json.JSONObject

data class Step(
    val id: String,
    val type: String,
    val code: String? = null,
    val text: String? = null,
    val pattern: String? = null,
    val saveAs: String? = null,
    val variable: String? = null,
    val op: String? = null,
    val value: String? = null,
    val ms: Long = 0,
    val timeoutMs: Long = 20000,
    val retries: Int = 0,
    val onMatch: String? = null,
    val onFail: String? = null,
    val next: String? = null,
    val thenId: String? = null,
    val elseId: String? = null,
)

data class Workflow(
    val name: String,
    val mode: String,            // auto | api | accessibility
    val simSlot: Int,            // -1 = default SIM
    val stopOnError: Boolean,
    val hideUi: Boolean,         // تغطية الشاشة أثناء التشغيل (وضع accessibility فقط)
    val delayBetweenRowsMs: Long,
    val variables: Map<String, String>,
    val steps: List<Step>,
)

object WorkflowParser {

    private val TYPES = setOf("dial", "reply", "expect", "if", "set", "delay", "log", "cancel", "end")
    private val OPS = setOf("lt", "gt", "le", "ge", "eq", "ne")

    private fun JSONObject.str(key: String): String? =
        if (has(key) && !isNull(key)) get(key).toString() else null

    fun parse(json: String): Workflow {
        val o = JSONObject(json)
        val vars = linkedMapOf<String, String>()
        o.optJSONObject("variables")?.let { v ->
            v.keys().forEach { k -> vars[k] = v.get(k).toString() }
        }
        val arr = o.getJSONArray("steps")
        val steps = (0 until arr.length()).map { i ->
            val s = arr.getJSONObject(i)
            Step(
                id = s.str("id") ?: "step${i + 1}",
                type = (s.str("type") ?: error("الخطوة ${i + 1}: الحقل type مفقود")).lowercase(),
                code = s.str("code"),
                text = s.str("text"),
                pattern = s.str("pattern"),
                saveAs = s.str("saveAs"),
                variable = s.str("variable"),
                op = s.str("op")?.lowercase(),
                value = s.str("value"),
                ms = s.optLong("ms", 0),
                timeoutMs = s.optLong("timeoutMs", 20000),
                retries = s.optInt("retries", 0),
                onMatch = s.str("onMatch"),
                onFail = s.str("onFail"),
                next = s.str("next"),
                thenId = s.str("then"),
                elseId = s.str("else"),
            )
        }
        val wf = Workflow(
            name = o.optString("name", "workflow"),
            mode = o.optString("mode", "auto").lowercase(),
            simSlot = o.optInt("simSlot", -1),
            stopOnError = o.optBoolean("stopOnError", false),
            hideUi = o.optBoolean("hideUi", true),
            delayBetweenRowsMs = o.optLong("delayBetweenRowsMs", 3000),
            variables = vars,
            steps = steps,
        )
        validate(wf)
        return wf
    }

    private fun validate(wf: Workflow) {
        require(wf.steps.isNotEmpty()) { "لا توجد خطوات في السيناريو" }
        require(wf.mode in setOf("auto", "api", "accessibility")) { "mode يجب أن يكون auto أو api أو accessibility" }
        val ids = wf.steps.map { it.id }
        require(ids.size == ids.toSet().size) { "يوجد id مكرر بين الخطوات" }
        val valid = ids.toSet() + setOf("end", "fail")
        fun checkTarget(stepId: String, t: String?) {
            require(t == null || t in valid) { "الخطوة $stepId: الهدف '$t' غير موجود" }
        }
        wf.steps.forEach { s ->
            require(s.type in TYPES) { "الخطوة ${s.id}: النوع '${s.type}' غير معروف" }
            when (s.type) {
                "dial" -> require(!s.code.isNullOrBlank()) { "الخطوة ${s.id}: code مطلوب" }
                "reply" -> require(s.text != null) { "الخطوة ${s.id}: text مطلوب" }
                "expect" -> {
                    require(!s.pattern.isNullOrEmpty()) { "الخطوة ${s.id}: pattern مطلوب" }
                    Regex(s.pattern!!)
                }
                "if" -> {
                    require(!s.variable.isNullOrBlank()) { "الخطوة ${s.id}: variable مطلوب" }
                    require(s.op != null || s.pattern != null) { "الخطوة ${s.id}: يلزم op+value أو pattern" }
                    s.op?.let { require(it in OPS) { "الخطوة ${s.id}: op غير صالح" } }
                    s.pattern?.let { Regex(it) }
                }
                "set" -> require(!s.variable.isNullOrBlank()) { "الخطوة ${s.id}: variable مطلوب" }
            }
            checkTarget(s.id, s.next)
            checkTarget(s.id, s.onMatch)
            checkTarget(s.id, s.onFail)
            checkTarget(s.id, s.thenId)
            checkTarget(s.id, s.elseId)
        }
    }
}
