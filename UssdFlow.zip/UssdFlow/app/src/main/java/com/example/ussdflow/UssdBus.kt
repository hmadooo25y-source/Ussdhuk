package com.example.ussdflow

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.channels.BufferOverflow

data class UssdScreen(val text: String, val hasInput: Boolean)

/** ناقل بين خدمة إمكانية الوصول والمحرك. armed = لا تقرأ أي شاشة إلا أثناء تشغيل سيناريو. */
object UssdBus {
    @Volatile var armed: Boolean = false
    val screens = MutableSharedFlow<UssdScreen>(
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
}
