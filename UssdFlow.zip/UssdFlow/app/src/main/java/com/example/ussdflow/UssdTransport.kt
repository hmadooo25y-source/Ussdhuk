package com.example.ussdflow

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class UssdException(msg: String) : Exception(msg)

interface UssdTransport {
    /** timeoutMs <= 0 في الوضع accessibility يعني: نفّذ ولا تنتظر ردًا. */
    suspend fun dial(code: String, timeoutMs: Long): String
    suspend fun reply(text: String, timeoutMs: Long): String
    suspend fun close()
}

/** TelephonyManager.sendUssdRequest: طلب واحد ورد واحد فقط (لا يدعم متابعة الجلسة). */
class ApiTransport(private val ctx: Context, private val simSlot: Int) : UssdTransport {

    @SuppressLint("MissingPermission")
    override suspend fun dial(code: String, timeoutMs: Long): String {
        var tm = ctx.getSystemService(TelephonyManager::class.java)
        if (simSlot >= 0) {
            val sub = ctx.getSystemService(SubscriptionManager::class.java)
                .getActiveSubscriptionInfoForSimSlotIndex(simSlot)?.subscriptionId
            if (sub != null) tm = tm.createForSubscriptionId(sub)
        }
        val manager = tm
        val result = withTimeoutOrNull(timeoutMs.coerceAtLeast(1000)) {
            suspendCancellableCoroutine<String> { cont ->
                manager.sendUssdRequest(
                    code,
                    object : TelephonyManager.UssdResponseCallback() {
                        override fun onReceiveUssdResponse(
                            telephonyManager: TelephonyManager, request: String, response: CharSequence,
                        ) {
                            if (cont.isActive) cont.resume(response.toString())
                        }

                        override fun onReceiveUssdResponseFailed(
                            telephonyManager: TelephonyManager, request: String, failureCode: Int,
                        ) {
                            if (cont.isActive) cont.resumeWithException(UssdException("فشل طلب USSD (code=$failureCode)"))
                        }
                    },
                    Handler(Looper.getMainLooper()),
                )
            }
        }
        return result ?: throw UssdException("انتهت المهلة بانتظار رد USSD")
    }

    override suspend fun reply(text: String, timeoutMs: Long): String =
        throw UssdException("وضع api لا يدعم الرد داخل الجلسة. فعّل خدمة إمكانية الوصول واستخدم mode=accessibility أو auto")

    override suspend fun close() {}
}

/** يطلب الرمز عبر ACTION_CALL ويقرأ/يكتب في نافذة USSD عبر خدمة إمكانية الوصول. */
class AccessibilityTransport(private val ctx: Context, private val simSlot: Int) : UssdTransport {

    private fun service(): UssdAccessibilityService =
        UssdAccessibilityService.instance
            ?: throw UssdException("خدمة إمكانية الوصول غير مفعّلة. فعّلها من الإعدادات")

    @SuppressLint("MissingPermission")
    private fun phoneAccount() =
        if (simSlot >= 0)
            ctx.getSystemService(TelecomManager::class.java).callCapablePhoneAccounts.getOrNull(simSlot)
        else null

    override suspend fun dial(code: String, timeoutMs: Long): String {
        service()
        return awaitScreen(timeoutMs) {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(code)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            phoneAccount()?.let { intent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
            ctx.startActivity(intent)
        }
    }

    override suspend fun reply(text: String, timeoutMs: Long): String {
        val svc = service()
        return awaitScreen(timeoutMs) {
            val ok = withContext(Dispatchers.Main) { svc.reply(text) }
            if (!ok) throw UssdException("لم أجد حقل إدخال أو زر إرسال في نافذة USSD")
        }
    }

    override suspend fun close() {
        val svc = UssdAccessibilityService.instance ?: return
        withContext(Dispatchers.Main) { svc.dismiss() }
        delay(300)
    }

    private suspend fun awaitScreen(timeoutMs: Long, action: suspend () -> Unit): String = coroutineScope {
        if (timeoutMs <= 0) {
            action()
            return@coroutineScope ""
        }
        // نشترك في التدفق قبل التنفيذ حتى لا يفوتنا الرد السريع
        val waiter = async(start = CoroutineStart.UNDISPATCHED) {
            withTimeoutOrNull(timeoutMs) { UssdBus.screens.first() }
        }
        action()
        waiter.await()?.text ?: throw UssdException("انتهت المهلة بانتظار نافذة USSD")
    }
}

object TransportFactory {
    fun create(ctx: Context, wf: Workflow): UssdTransport = when (wf.mode) {
        "api" -> ApiTransport(ctx, wf.simSlot)
        "accessibility" -> AccessibilityTransport(ctx, wf.simSlot)
        else -> if (UssdAccessibilityService.instance != null)
            AccessibilityTransport(ctx, wf.simSlot)
        else
            ApiTransport(ctx, wf.simSlot)
    }
}
